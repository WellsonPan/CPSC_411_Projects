package com.example.wells.miniapp1

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import java.text.DecimalFormat
import kotlinx.android.synthetic.main.fragment_one.*

class FragmentOne : Fragment() {

    private val thing = object : TextWatcher {

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            if (editText.text.toString() != "" && editText2.text.toString() != "") {
                val idk = editText.text
                val idk2 = editText2.text
                val but = idk.toString()
                val but2 = idk2.toString()
                val why = Integer.parseInt(but)
                val why2 = Integer.parseInt(but2)

                val mibConverted = why2.toDouble() * 1.048576
                val convertedTime = mibConverted / why.toDouble()
                val formatter = DecimalFormat("#0.0")
                val formatterTemp = formatter.format(convertedTime) + " secs"
                textView4.text = formatterTemp
            }
            else
            {
                textView4.setText(R.string.validity)
            }
        }

        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        override fun afterTextChanged(p0: Editable?) {
            //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }
    }

    override fun onStart() {
        super.onStart()
        editText.addTextChangedListener(thing)
        editText2.addTextChangedListener(thing)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val fragView = inflater.inflate(R.layout.fragment_one, container, false)
        return fragView
    }

    companion object {
        fun newInstance():FragmentOne
        {
            return FragmentOne()
        }
    }
}
