package com.example.wells.miniapp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.transaction

import kotlinx.android.synthetic.main.fragment_one.*

class MainActivity : AppCompatActivity(){

    var saveTime: String? = ""

    override fun onSaveInstanceState(outState: Bundle?) {
        outState?.putString(STATE_FRAGMENT, saveTime)
        super.onSaveInstanceState(outState)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState != null)
        {
            if (savedInstanceState.getString(STATE_FRAGMENT) != null)
            {
                saveTime = savedInstanceState.getString(STATE_FRAGMENT)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        displayFrag()
    }

    override fun onResume() {
        super.onResume()
        if (saveTime != null)
        {
            textView4.text = saveTime
        }
    }

    override fun onPause() {
        super.onPause()
        if (textView4.text.toString() != "") {
            saveTime = textView4.text.toString()
        }
        closeFrag()
    }

    fun displayFrag()
    {
        val firstFrag = FragmentOne.newInstance()
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.transaction{
            add(R.id.fragmentOne, firstFrag)
            addToBackStack(null)
        }
    }

    fun closeFrag()
    {
        val fragmentManager = supportFragmentManager
        val firstFrag = fragmentManager.findFragmentById(R.id.fragmentOne) as FragmentOne
        if (firstFrag != null)
        {
            val fragmentTransaction = fragmentManager.transaction(){
                remove(firstFrag)
            }
        }
    }

    companion object {
        internal val STATE_FRAGMENT = "timeVal"
    }
}
