package com.example.wells.miniapp1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.TextView

import java.text.DecimalFormat

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val thing = object : TextWatcher {

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                if (editText.text.toString() != "" && editText2.text.toString() != "") {
                    val butts = editText.text
                    val butts2 = editText2.text
                    val but = butts.toString()
                    val but2 = butts2.toString()
                    val why = Integer.parseInt(but)
                    val why2 = Integer.parseInt(but2)

                    val mibConverted = why2.toDouble() * 1.048576
                    val convertedTime = mibConverted / why.toDouble()
                    val formatter = DecimalFormat("#0.0")
                    textView4.text = formatter.format(convertedTime) + " secs"
                }
                else
                {
                    textView4.setText(R.string.validity)
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun afterTextChanged(p0: Editable?) {
                //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }
        }

        editText.addTextChangedListener(thing)
        editText2.addTextChangedListener(thing)
    }
}
